package exceptions;

public class InputFileException extends Exception {

	public InputFileException(String string) {
		super(string);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = -1935686855339298956L;

}
