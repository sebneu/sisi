package interpreter.tree.types;

public class SetType extends Type {

    public SetType() {
	super(SET);
    }

}
