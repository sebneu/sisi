package interpreter.tree.types;

public class MType extends Type {

    public MType() {
	super(MTYPE);
    }
}
