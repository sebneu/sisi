package interpreter.tree.types;

import interpreter.tree.Enums;

public class EnumEntryType extends Type {

    public EnumEntryType(String typeId, Enums enums) {
	super(typeId, enums);
    }

}
