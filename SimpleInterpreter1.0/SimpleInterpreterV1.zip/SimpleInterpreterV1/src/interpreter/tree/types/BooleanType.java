package interpreter.tree.types;

public class BooleanType extends Type {

    public BooleanType() {
	super(BOOLEAN);
    }

}
