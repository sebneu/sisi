package interpreter.tree.types;

public class IntegerType extends Type {

    public IntegerType() {
	super(INTEGER);
    }

}
