package interpreter.tree;


public class ReceiveTupleSignatur extends TupleSignatur {

    public void addMType(String id) {
	identifier.add(id);
    }

}
