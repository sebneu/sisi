package interpreter.tree.nodes;

public interface OperationOnSetNode extends Node {

    void set(String string);
    
}
