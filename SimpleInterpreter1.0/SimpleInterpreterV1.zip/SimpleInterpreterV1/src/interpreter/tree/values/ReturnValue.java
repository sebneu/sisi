package interpreter.tree.values;

public interface ReturnValue {
}
